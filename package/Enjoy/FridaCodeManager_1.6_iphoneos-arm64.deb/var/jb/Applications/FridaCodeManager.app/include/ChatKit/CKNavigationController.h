#import <UIKit/UINavigationController.h>

@interface CKNavigationController : UINavigationController

@end
