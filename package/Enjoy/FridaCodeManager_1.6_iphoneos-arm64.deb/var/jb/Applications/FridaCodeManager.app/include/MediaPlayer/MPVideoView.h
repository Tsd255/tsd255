#import <UIKit/UIView.h>

@interface MPVideoView : UIView

@end
