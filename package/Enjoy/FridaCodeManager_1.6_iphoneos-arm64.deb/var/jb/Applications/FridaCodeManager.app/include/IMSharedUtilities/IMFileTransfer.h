#import <Foundation/NSObject.h>
#import <Foundation/NSString.h>

@interface IMFileTransfer : NSObject

@property (nonatomic, retain) NSString *messageGUID;
@property (nonatomic, retain) NSString *otherPerson;

@end
