#import <UIKit/UIView.h>

@interface SBFolderSlidingView : UIView

@end
