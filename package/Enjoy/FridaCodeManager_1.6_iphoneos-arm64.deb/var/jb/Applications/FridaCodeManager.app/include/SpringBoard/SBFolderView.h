#import <UIKit/UIView.h>

@interface SBFolderView : UIView

- (void)setPageControlHidden:(BOOL)hidden;

@end
