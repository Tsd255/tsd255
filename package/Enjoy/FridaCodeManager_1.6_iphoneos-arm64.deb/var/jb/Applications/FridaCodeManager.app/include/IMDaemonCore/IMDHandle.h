#import <Foundation/NSObject.h>
#import <Foundation/NSString.h>

@interface IMDHandle : NSObject

@property (nonatomic, retain) NSString *ID;

@end
