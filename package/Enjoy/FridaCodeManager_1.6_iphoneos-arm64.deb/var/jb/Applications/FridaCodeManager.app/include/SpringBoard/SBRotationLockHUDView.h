#import "SBHUDView.h"

@interface SBRotationLockHUDView : SBHUDView

@end
