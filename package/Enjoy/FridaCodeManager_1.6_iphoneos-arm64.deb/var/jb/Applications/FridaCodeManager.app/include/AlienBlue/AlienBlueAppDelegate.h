#import <UIKit/UIApplication.h>
#import <UIKit/UIWindow.h>

@interface AlienBlueAppDelegate : NSObject <UIApplicationDelegate>

@property (nonatomic, retain) UIWindow *window;

@end
