#import <UIKit/UIView.h>

@interface SBBannerContextView : UIView

@end
