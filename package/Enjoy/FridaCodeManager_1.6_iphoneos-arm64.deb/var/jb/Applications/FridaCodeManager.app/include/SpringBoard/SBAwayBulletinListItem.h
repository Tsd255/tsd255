#import "SBAwayListItem.h"

@class BBBulletin;

@interface SBAwayBulletinListItem : SBAwayListItem

@property (nonatomic, retain) BBBulletin *activeBulletin;

@end
