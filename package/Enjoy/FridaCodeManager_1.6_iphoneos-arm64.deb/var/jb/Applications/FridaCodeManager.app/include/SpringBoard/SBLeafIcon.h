#import "SBIcon.h"

@interface SBLeafIcon : SBIcon

- (instancetype)initWithLeafIdentifier:(NSString *)leafIdentifier applicationBundleID:(NSString *)bundleID;

@end
