#import <UIKit/UITableViewCell.h>
#import <UIKit/UIImageView.h>

@interface NowPlayingDrawerCell : UITableViewCell

@property (nonatomic, retain) UIImageView *leftImageView;

@end
