#import <Preferences/PSRootController.h>

@class PSUIPrefsListController;

@interface PSUIPrefsRootController : PSRootController

- (PSUIPrefsListController *)rootListController;

@end
