#import <UIKit/UIImage.h>

@interface SBWallpaperPreviewSnapshotCache : NSObject

- (UIImage *)homeScreenSnapshot;
- (UIImage *)lockScreenSnapshot;

@end
