#import <Foundation/Foundation.h>

API_AVAILABLE(ios(7.0))
@interface AVCaptureDeviceFormat_FigRecorder : NSObject

- (instancetype)initWithDictionary:(NSDictionary *)dictionary;

@end
