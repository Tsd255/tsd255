// app

#import <UIKit/UICollectionView.h>

@interface WorldClockCollectionView : UICollectionView

@end
