#import "FBSSceneSettings.h"

@interface FBSMutableSceneSettings : FBSSceneSettings

@property (nonatomic, assign, getter=isBackgrounded) BOOL backgrounded;

@end
