#import <UIKit/UIView.h>

@interface SBDefaultBannerView : UIView

@end
