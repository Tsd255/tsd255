#import "SBNotificationCell.h"

@interface SBNotificationsBulletinCell : SBNotificationCell

@end
