#import <UIKit/UIKit.h>

@interface SBTodayBulletinCell : UITableViewCell

+ (NSDictionary *)defaultTextAttributes;
+ (UIColor *)defaultFontColor;
+ (UIFont *)defaultFont;

@end
