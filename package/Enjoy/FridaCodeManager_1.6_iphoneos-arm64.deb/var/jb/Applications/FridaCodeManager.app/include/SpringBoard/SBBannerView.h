#import <UIKit/UIView.h>

NS_CLASS_DEPRECATED_IOS(5_0, 6_0) @interface SBBannerView : UIView

@end
