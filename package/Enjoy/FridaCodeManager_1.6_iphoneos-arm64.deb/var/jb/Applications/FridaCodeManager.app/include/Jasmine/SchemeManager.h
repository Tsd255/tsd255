#import <Foundation/NSObject.h>
#import <Foundation/NSURL.h>

@interface SchemeManager : NSObject

+ (void)handleVideoOpen:(NSURL *)url;

@end
