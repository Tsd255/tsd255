#import <UIKit/UIView.h>

@interface SBAwayView : UIView

@end
