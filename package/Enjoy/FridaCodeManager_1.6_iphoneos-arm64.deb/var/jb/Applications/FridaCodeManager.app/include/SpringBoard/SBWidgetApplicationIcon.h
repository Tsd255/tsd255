#import <Foundation/Foundation.h>

@interface SBWidgetApplicationIcon : NSObject

@end
