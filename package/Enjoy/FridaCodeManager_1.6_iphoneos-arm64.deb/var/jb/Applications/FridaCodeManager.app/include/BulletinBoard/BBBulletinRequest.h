#import "BBBulletin.h"

@interface BBBulletinRequest : BBBulletin

@property (nonatomic, copy) NSArray *supplementaryActions;
@property (nonatomic, copy) NSDictionary *supplementaryActionsByLayout;

@end
