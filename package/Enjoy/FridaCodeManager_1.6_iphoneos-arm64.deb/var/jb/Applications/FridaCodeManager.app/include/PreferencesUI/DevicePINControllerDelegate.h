#import <Foundation/Foundation.h>

@protocol DevicePINControllerDelegate <NSObject>

@end
