#import <UIKit/UIImage.h>

@interface PLManagedAsset : NSObject

- (UIImage *)newFullSizeImage;

@end
